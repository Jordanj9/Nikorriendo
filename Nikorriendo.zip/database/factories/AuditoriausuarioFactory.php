<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Auditoriausuario;
use Faker\Generator as Faker;

$factory->define(Auditoriausuario::class, function (Faker $faker) {
    return [
        //
    ];
});
