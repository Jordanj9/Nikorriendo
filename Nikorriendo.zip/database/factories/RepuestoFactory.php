<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Repuesto;
use Faker\Generator as Faker;

$factory->define(Repuesto::class, function (Faker $faker) {
    return [
        //
    ];
});
