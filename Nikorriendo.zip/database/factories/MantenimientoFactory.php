<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Mantenimiento;
use Faker\Generator as Faker;

$factory->define(Mantenimiento::class, function (Faker $faker) {
    return [
        //
    ];
});
