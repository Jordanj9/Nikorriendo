<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Lavadora_persona;
use Faker\Generator as Faker;

$factory->define(Lavadora_persona::class, function (Faker $faker) {
    return [
        //
    ];
});
