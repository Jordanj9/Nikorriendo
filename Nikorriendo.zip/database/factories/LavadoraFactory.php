<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Lavadora;
use Faker\Generator as Faker;

$factory->define(Lavadora::class, function (Faker $faker) {
    return [
        //
    ];
});
