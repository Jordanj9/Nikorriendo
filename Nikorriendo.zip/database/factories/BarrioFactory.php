<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Barrio;
use Faker\Generator as Faker;

$factory->define(Barrio::class, function (Faker $faker) {
    return [
        //
    ];
});
