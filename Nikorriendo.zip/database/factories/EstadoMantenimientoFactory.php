<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Estado_mantenimiento;
use Faker\Generator as Faker;

$factory->define(Estado_mantenimiento::class, function (Faker $faker) {
    return [
        //
    ];
});
