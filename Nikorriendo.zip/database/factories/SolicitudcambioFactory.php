<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Solicitudcambio;
use Faker\Generator as Faker;

$factory->define(Solicitudcambio::class, function (Faker $faker) {
    return [
        //
    ];
});
