<?php

namespace App\Http\Controllers;

use App\Auditoriausuario;
use Illuminate\Http\Request;

class AuditoriausuarioController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Auditoriausuario  $auditoriausuario
     * @return \Illuminate\Http\Response
     */
    public function show(Auditoriausuario $auditoriausuario)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Auditoriausuario  $auditoriausuario
     * @return \Illuminate\Http\Response
     */
    public function edit(Auditoriausuario $auditoriausuario)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Auditoriausuario  $auditoriausuario
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Auditoriausuario $auditoriausuario)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Auditoriausuario  $auditoriausuario
     * @return \Illuminate\Http\Response
     */
    public function destroy(Auditoriausuario $auditoriausuario)
    {
        //
    }
}
