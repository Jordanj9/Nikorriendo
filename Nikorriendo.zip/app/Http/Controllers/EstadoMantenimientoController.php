<?php

namespace App\Http\Controllers;

use App\Estado_mantenimiento;
use Illuminate\Http\Request;

class EstadoMantenimientoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Estado_mantenimiento  $estado_mantenimiento
     * @return \Illuminate\Http\Response
     */
    public function show(Estado_mantenimiento $estado_mantenimiento)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Estado_mantenimiento  $estado_mantenimiento
     * @return \Illuminate\Http\Response
     */
    public function edit(Estado_mantenimiento $estado_mantenimiento)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Estado_mantenimiento  $estado_mantenimiento
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Estado_mantenimiento $estado_mantenimiento)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Estado_mantenimiento  $estado_mantenimiento
     * @return \Illuminate\Http\Response
     */
    public function destroy(Estado_mantenimiento $estado_mantenimiento)
    {
        //
    }
}
